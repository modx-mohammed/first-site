
import React, { createContext, useContext, useState, useEffect } from 'react';

interface Vehicle {
  model: string;
  plate: string;
  type: string;
}

interface Property {
  name: string;
  location: string;
  price: number;
}

interface UserStats {
  cash: number;
  bank: number;
  points: number; // النقاط المكتسبة من الألعاب
  job: string;
  rank: string;
  playtime: string;
  level: number;
  warnings: number;
  jailTime: number;
  joinDate: string;
  vehicles: Vehicle[];
  properties: Property[];
  licenses: {
    driver: boolean;
    pilot: boolean;
    weapon: boolean;
  };
}

interface User {
  username: string;
  displayName: string;
  avatar: string;
  id: string;
  discordId: string;
  status: string;
  stats: UserStats;
}

interface AuthContextType {
  user: User | null;
  login: (userData: User) => void;
  updateUser: (newData: Partial<User>) => void;
  updateStats: (newStats: Partial<UserStats>) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('blaine_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem('blaine_user', JSON.stringify(userData));
  };

  const updateUser = (newData: Partial<User>) => {
    if (user) {
      const updated = { ...user, ...newData };
      setUser(updated);
      localStorage.setItem('blaine_user', JSON.stringify(updated));
    }
  };

  const updateStats = (newStats: Partial<UserStats>) => {
    if (user) {
      const updatedUser = {
        ...user,
        stats: { ...user.stats, ...newStats }
      };
      setUser(updatedUser);
      localStorage.setItem('blaine_user', JSON.stringify(updatedUser));
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('blaine_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, updateUser, updateStats, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
