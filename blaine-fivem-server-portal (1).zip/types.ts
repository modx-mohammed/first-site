
export interface StaffMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  discord?: string;
}

export interface Rule {
  id: number;
  title: string;
  content: string;
}

export interface ServerStats {
  playersOnline: number;
  maxPlayers: number;
  serverStatus: 'online' | 'offline' | 'maintenance';
  uptime: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
