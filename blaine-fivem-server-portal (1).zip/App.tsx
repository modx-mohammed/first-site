
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Rules from './components/Rules';
import Staff from './components/Staff';
import Footer from './components/Footer';
import Assistant from './components/Assistant';
import RulesPage from './components/RulesPage';
import FeaturesPage from './components/FeaturesPage';
import StaffPage from './components/StaffPage';
import StorePage from './components/StorePage';
import ApplicationsPage from './components/ApplicationsPage';
import ProfilePage from './components/ProfilePage';
import { AuthProvider } from './context/AuthContext';
import { CONFIG } from './config';
import { fetchServerStats } from './services/apiService';

type ViewType = 'home' | 'rules' | 'features' | 'staff' | 'store' | 'applications' | 'profile';

const AppContent: React.FC = () => {
  const [view, setView] = useState<ViewType>('home');
  const [copied, setCopied] = useState(false);
  const [serverInfo, setServerInfo] = useState({ online: 0, status: 'loading' });

  useEffect(() => {
    window.scrollTo(0, 0);
    // جلب إحصائيات السيرفر عند تحميل الصفحة
    const getStats = async () => {
      const stats = await fetchServerStats();
      setServerInfo(stats);
    };
    getStats();
  }, [view]);

  const handleCopyIP = () => {
    navigator.clipboard.writeText(CONFIG.SERVER.IP);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const navigateTo = (target: ViewType) => {
    setView(target);
  };

  const renderView = () => {
    switch(view) {
      case 'rules': return <RulesPage onBack={() => navigateTo('home')} />;
      case 'features': return <FeaturesPage onBack={() => navigateTo('home')} />;
      case 'staff': return <StaffPage onBack={() => navigateTo('home')} />;
      case 'store': return <StorePage onBack={() => navigateTo('home')} />;
      case 'applications': return <ApplicationsPage onBack={() => navigateTo('home')} />;
      case 'profile': return <ProfilePage onBack={() => navigateTo('home')} onNavigate={navigateTo} />;
      default: return (
        <>
          <Hero />
          <div className="max-w-7xl mx-auto px-6 -mt-10 relative z-20 hidden lg:block">
            <div className="glass-panel p-8 rounded-3xl grid grid-cols-4 gap-4 items-center">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 ${serverInfo.status === 'online' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'} rounded-2xl flex items-center justify-center text-2xl`}>⚡</div>
                <div>
                  <p className="text-xs text-gray-500 font-bold">حالة السيرفر</p>
                  <p className={`text-lg font-black ${serverInfo.status === 'online' ? 'text-green-500' : 'text-red-500'}`}>
                    {serverInfo.status === 'online' ? 'متصل' : 'أوفلاين'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 text-2xl">👥</div>
                <div><p className="text-xs text-gray-500 font-bold">المتصلون الحقيقيون</p><p className="text-lg font-black">{serverInfo.online} لاعب</p></div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-500 text-2xl">📍</div>
                <div><p className="text-xs text-gray-500 font-bold">الإصدار</p><p className="text-lg font-black">{CONFIG.SERVER.VERSION}</p></div>
              </div>
              <button onClick={handleCopyIP} className={`py-3 rounded-2xl font-black text-sm transition-all transform hover:scale-105 ${copied ? 'bg-green-600' : 'bg-blue-600'}`}>{copied ? 'تم النسخ!' : 'نسخ IP السيرفر'}</button>
            </div>
          </div>
          <Rules onNavigate={navigateTo} />
          <section className="py-24 px-6 text-center">
            <h2 className="text-4xl font-black mb-8">انضم إلى طاقمنا الآن</h2>
            <button onClick={() => navigateTo('applications')} className="px-10 py-4 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 rounded-2xl transition-all font-black text-xl">عرض جميع التقديمات</button>
          </section>
          <Staff />
        </>
      );
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-white">
      <Navbar onNavigate={navigateTo} />
      <main>{renderView()}</main>
      <Footer onNavigate={navigateTo} />
      <Assistant />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;
