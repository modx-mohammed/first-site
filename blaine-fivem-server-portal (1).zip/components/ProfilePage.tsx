
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import EditProfileModal from './EditProfileModal';
import GameHub from './GameHub';

interface ProfilePageProps {
  onBack: () => void;
  onNavigate: (target: any) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onBack, onNavigate }) => {
  const { user, isAuthenticated } = useAuth();
  const [isSyncing, setIsSyncing] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'assets' | 'games' | 'logs'>('overview');
  
  useEffect(() => { window.scrollTo(0, 0); }, []);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      alert("تمت مزامنة بياناتك مع السيرفر بنجاح!");
    }, 2500);
  };

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0b]">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">يجب تسجيل الدخول أولاً</h2>
          <button onClick={onBack} className="bg-blue-600 px-6 py-2 rounded-xl">العودة للرئيسية</button>
        </div>
      </div>
    );
  }

  const stats = user.stats;

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Profile Banner & Header */}
        <div className="relative mb-12">
          <div className="h-48 w-full bg-gradient-to-r from-blue-600 to-purple-600 rounded-[3rem] opacity-20 blur-xl absolute -z-10"></div>
          <div className="glass-panel p-10 rounded-[3rem] border-white/5 flex flex-col md:flex-row items-center gap-10">
            <div className="relative">
              <img src={user.avatar} className="w-40 h-40 rounded-[2.5rem] border-4 border-blue-600/40 shadow-2xl object-cover" alt="User Avatar" />
              <div className="absolute -bottom-2 -right-2 bg-green-500 w-10 h-10 rounded-full border-[6px] border-[#0a0a0b] flex items-center justify-center">
                <span className="text-[10px] font-black">Online</span>
              </div>
            </div>
            
            <div className="text-center md:text-right flex-1">
              <div className="flex flex-col md:flex-row items-center gap-4 mb-3">
                <h1 className="text-5xl font-black tracking-tighter">{user.displayName || user.username}</h1>
                <span className="text-gray-500 font-mono text-lg">@{user.username}</span>
              </div>
              <p className="text-gray-400 text-lg mb-6 italic max-w-xl">"{user.status || 'لا يوجد حالة شخصية حالياً'}"</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-3">
                <span className="bg-blue-600/20 text-blue-400 px-5 py-2 rounded-2xl font-bold border border-blue-500/10">ID: {user.id}</span>
                <span className="bg-green-600/20 text-green-400 px-5 py-2 rounded-2xl font-bold border border-green-500/10">عضو منذ: {stats.joinDate}</span>
                <span className="bg-purple-600/20 text-purple-400 px-5 py-2 rounded-2xl font-bold border border-purple-500/10">{stats.rank}</span>
                <span className="bg-yellow-500/20 text-yellow-500 px-5 py-2 rounded-2xl font-bold border border-yellow-500/10">🪙 {stats.points} نقطة</span>
              </div>
            </div>

            <div className="flex flex-col gap-4 w-full md:w-auto">
              <button 
                onClick={() => setIsEditOpen(true)}
                className="bg-white text-black hover:bg-blue-600 hover:text-white px-8 py-4 rounded-[1.5rem] font-black transition-all transform active:scale-95"
              >
                تعديل الملف
              </button>
              <button 
                onClick={handleSync}
                disabled={isSyncing}
                className="bg-blue-600/10 hover:bg-blue-600/20 text-blue-500 border border-blue-500/20 px-8 py-4 rounded-[1.5rem] font-black transition-all flex items-center justify-center gap-2"
              >
                {isSyncing ? <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div> : '🔄 تحديث البيانات'}
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-6 mb-12 border-b border-white/5 px-4 overflow-x-auto whitespace-nowrap scrollbar-hide">
          <button 
            onClick={() => setActiveTab('overview')}
            className={`pb-4 px-4 font-black transition-all relative ${activeTab === 'overview' ? 'text-blue-500' : 'text-gray-500 hover:text-white'}`}
          >
            نظرة عامة
            {activeTab === 'overview' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('assets')}
            className={`pb-4 px-4 font-black transition-all relative ${activeTab === 'assets' ? 'text-blue-500' : 'text-gray-500 hover:text-white'}`}
          >
            الممتلكات ({stats.vehicles.length + stats.properties.length})
            {activeTab === 'assets' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('games')}
            className={`pb-4 px-4 font-black transition-all relative ${activeTab === 'games' ? 'text-blue-500' : 'text-gray-500 hover:text-white'}`}
          >
            الألعاب والمكافآت
            {activeTab === 'games' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('logs')}
            className={`pb-4 px-4 font-black transition-all relative ${activeTab === 'logs' ? 'text-blue-500' : 'text-gray-500 hover:text-white'}`}
          >
            السجل الإداري
            {activeTab === 'logs' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full"></div>}
          </button>
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Financial Grid */}
            <div className="lg:col-span-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="glass-panel p-10 rounded-[3rem] bg-gradient-to-br from-green-600/10 to-transparent">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-4xl">💰</span>
                    <span className="text-xs font-black text-green-500 bg-green-500/10 px-3 py-1 rounded-full">LIVE</span>
                  </div>
                  <p className="text-gray-500 font-bold text-sm uppercase mb-1">إجمالي الكاش</p>
                  <h3 className="text-4xl font-black">${stats.cash.toLocaleString()}</h3>
                </div>
                <div className="glass-panel p-10 rounded-[3rem] bg-gradient-to-br from-blue-600/10 to-transparent">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-4xl">🏦</span>
                    <span className="text-xs font-black text-blue-500 bg-blue-500/10 px-3 py-1 rounded-full">SECURE</span>
                  </div>
                  <p className="text-gray-500 font-bold text-sm uppercase mb-1">الرصيد البنكي</p>
                  <h3 className="text-4xl font-black">${stats.bank.toLocaleString()}</h3>
                </div>
              </div>

              <div className="glass-panel p-10 rounded-[3rem] relative overflow-hidden">
                <div className="absolute top-10 left-10 text-9xl font-black text-white/5 -rotate-12 select-none">LEVEL {stats.level}</div>
                <h3 className="text-2xl font-black mb-10 flex items-center gap-3">
                  <span className="w-2 h-8 bg-blue-600 rounded-full"></span>
                  إحصائيات التقدم واللعب
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
                   <div>
                     <p className="text-gray-500 text-xs font-black mb-2 uppercase">المهمة الحالية</p>
                     <p className="text-2xl font-bold">{stats.job}</p>
                     <p className="text-blue-500 text-sm">{stats.rank}</p>
                   </div>
                   <div>
                     <p className="text-gray-500 text-xs font-black mb-2 uppercase">ساعات اللعب</p>
                     <p className="text-2xl font-bold">{stats.playtime}</p>
                     <p className="text-gray-400 text-sm">إجمالي الوقت المسجل</p>
                   </div>
                   <div>
                     <p className="text-gray-500 text-xs font-black mb-2 uppercase">مستوى الخبرة</p>
                     <div className="w-full bg-white/5 h-2 rounded-full mt-3 overflow-hidden">
                        <div className="bg-blue-600 h-full" style={{width: '65%'}}></div>
                     </div>
                     <p className="text-right text-[10px] mt-2 text-gray-500 font-bold">65% للمستوى القادم</p>
                   </div>
                </div>
              </div>

              <div className="p-8 bg-yellow-500/5 border border-yellow-500/20 rounded-[2.5rem] flex items-center gap-6">
                 <div className="text-4xl">💡</div>
                 <div>
                   <h4 className="font-black text-yellow-500">نصيحة الربط المباشر</h4>
                   <p className="text-gray-400 text-sm">إذا لم تظهر بياناتك، استخدم أمر <code className="bg-black/50 px-2 py-1 rounded">/link</code> داخل السيرفر لربط حساب الديسكورد باللاعب.</p>
                 </div>
              </div>
            </div>

            <div className="lg:col-span-4 space-y-8">
              <div className="glass-panel p-8 rounded-[2.5rem] bg-yellow-500/10 border-yellow-500/20">
                <h3 className="text-xl font-black mb-4">🪙 نقاط المكافآت</h3>
                <p className="text-gray-400 text-sm mb-6">لديك حالياً {stats.points} نقطة جاهزة للاستبدال.</p>
                <button 
                  onClick={() => setActiveTab('games')}
                  className="w-full py-3 bg-yellow-500 text-black font-black rounded-xl hover:scale-105 transition-all"
                >
                  العب واجمع النقاط
                </button>
              </div>

              <div className="glass-panel p-8 rounded-[2.5rem]">
                <h3 className="text-xl font-black mb-6">الحالة الجنائية</h3>
                <div className="space-y-4">
                  <div className="flex justify-between p-4 bg-white/5 rounded-2xl">
                    <span className="text-gray-400 font-bold">التحذيرات الإدارية</span>
                    <span className={`font-black ${stats.warnings > 0 ? 'text-red-500' : 'text-green-500'}`}>{stats.warnings} / 3</span>
                  </div>
                  <div className="flex justify-between p-4 bg-white/5 rounded-2xl">
                    <span className="text-gray-400 font-bold">ساعات السجن</span>
                    <span className="font-black text-orange-500">{stats.jailTime} دقيقة</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'assets' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 animate-in fade-in slide-in-from-bottom-5">
             <div>
                <h3 className="text-2xl font-black mb-8 flex items-center gap-4">
                  <span className="text-4xl">🏎️</span> كراج المركبات ({stats.vehicles.length})
                </h3>
                <div className="grid gap-4">
                  {stats.vehicles.map((v, i) => (
                    <div key={i} className="glass-panel p-6 rounded-3xl border-white/5 flex justify-between items-center group hover:bg-white/5 transition-all">
                      <div>
                        <p className="font-black text-xl">{v.model}</p>
                        <p className="text-sm text-blue-500 font-bold uppercase">{v.type}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 font-bold mb-1">لوحة السيارة</p>
                        <p className="bg-white/10 px-3 py-1 rounded-lg font-mono font-bold">{v.plate}</p>
                      </div>
                    </div>
                  ))}
                </div>
             </div>
             <div>
                <h3 className="text-2xl font-black mb-8 flex items-center gap-4">
                  <span className="text-4xl">🏠</span> العقارات والبيوت ({stats.properties.length})
                </h3>
                <div className="grid gap-4">
                  {stats.properties.map((p, i) => (
                    <div key={i} className="glass-panel p-6 rounded-3xl border-white/5 flex justify-between items-center hover:bg-white/5 transition-all">
                      <div>
                        <p className="font-black text-xl">{p.name}</p>
                        <p className="text-sm text-green-500 font-bold">{p.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500 font-bold mb-1">القيمة السوقية</p>
                        <p className="font-black">${p.price.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
             </div>
          </div>
        )}

        {activeTab === 'games' && <GameHub />}

        {activeTab === 'logs' && (
          <div className="glass-panel p-10 rounded-[3rem] animate-in fade-in">
             <div className="text-center py-20">
                <div className="text-6xl mb-6">🛡️</div>
                <h3 className="text-2xl font-black mb-2">سجلك نظيف تماماً!</h3>
                <p className="text-gray-500">لا توجد أي عقوبات إدارية أو مخالفات مسجلة على حسابك.</p>
             </div>
          </div>
        )}
      </div>
      
      <EditProfileModal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} />
    </div>
  );
};

export default ProfilePage;
