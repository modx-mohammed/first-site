
import React, { useEffect } from 'react';

interface FeaturesPageProps {
  onBack: () => void;
}

const FeaturesPage: React.FC<FeaturesPageProps> = ({ onBack }) => {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  const features = [
    {
      title: "نظام اقتصاد متوازن",
      desc: "نظام بنكي متطور مع بطاقات ائتمان، وقروض، وتجارة أسهم واقعية تضمن استدامة اللعب.",
      icon: "💎"
    },
    {
      title: "سيارات واقعية حصرية",
      desc: "أكثر من 200 سيارة معدلة بفيزياء قيادة واقعية وأصوات محركات حقيقية.",
      icon: "🏎️"
    },
    {
      title: "وظائف حكومية ومدنية",
      desc: "أنظمة متطورة للشرطة والإسعاف والميكانيك، بالإضافة لوظائف حرة مثل الصيد والزراعة.",
      icon: "👷"
    },
    {
      title: "نظام عقارات متطور",
      desc: "يمكنك شراء أي منزل في الخريطة وتأثيثه بالكامل حسب ذوقك الخاص.",
      icon: "🏠"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto">
        <button onClick={onBack} className="text-blue-500 hover:text-blue-400 font-bold flex items-center gap-2 mb-8">
          <span>←</span> العودة للرئيسية
        </button>
        <h1 className="text-5xl font-black mb-12">مميزات سيرفر <span className="text-blue-500">بلاين</span></h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((f, i) => (
            <div key={i} className="glass-panel p-10 rounded-[3rem] hover:bg-white/[0.05] transition-all group">
              <div className="text-5xl mb-6 transform group-hover:scale-110 transition-transform inline-block">{f.icon}</div>
              <h3 className="text-2xl font-bold mb-4">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed text-lg">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturesPage;
