
import React, { useEffect } from 'react';

interface ApplicationsPageProps {
  onBack: () => void;
}

const ApplicationsPage: React.FC<ApplicationsPageProps> = ({ onBack }) => {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  const jobs = [
    {
      title: "تقديم الشرطة",
      desc: "كن حامياً للقانون وحافظ على أمن مدينة بلاين.",
      icon: "👮‍♂️",
      color: "border-blue-600",
      link: "https://discord.gg/blaine"
    },
    {
      title: "تقديم الحرس",
      desc: "انضم للقوات الخاصة لحماية المنشآت الحيوية في الولاية.",
      icon: "💂‍♂️",
      color: "border-green-700",
      link: "https://discord.gg/blaine"
    },
    {
      title: "تقديم الهلال الأحمر",
      desc: "ساهم في إنقاذ الأرواح وتقديم الخدمات الطبية العاجلة.",
      icon: "🚑",
      color: "border-red-600",
      link: "https://discord.gg/blaine"
    },
    {
      title: "تقديم كراج الميكانيكي",
      desc: "أظهر مهارتك في إصلاح وتعديل أسرع السيارات في المدينة.",
      icon: "🔧",
      color: "border-orange-500",
      link: "https://discord.gg/blaine"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto">
        <button onClick={onBack} className="text-blue-500 hover:text-blue-400 font-bold flex items-center gap-2 mb-8 transition-colors">
          <span>←</span> العودة للرئيسية
        </button>
        
        <div className="text-center mb-16">
          <h1 className="text-5xl font-black mb-4">طلبات <span className="text-blue-500">التوظيف</span></h1>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">اختر القطاع الذي ترغب في الانضمام إليه وابدأ مسيرتك المهنية في سيرفر بلاين.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {jobs.map((job, i) => (
            <div key={i} className={`glass-panel p-10 rounded-[3rem] border-r-4 ${job.color} group hover:bg-white/[0.05] transition-all`}>
              <div className="flex items-center gap-6 mb-6">
                <div className="text-6xl group-hover:scale-110 transition-transform">{job.icon}</div>
                <div>
                  <h3 className="text-2xl font-black mb-2">{job.title}</h3>
                  <div className="h-1 w-12 bg-blue-600 rounded-full"></div>
                </div>
              </div>
              <p className="text-gray-400 text-lg mb-8 leading-relaxed">{job.desc}</p>
              <button 
                onClick={() => window.open(job.link, '_blank')}
                className="w-full py-4 bg-white/5 border border-white/10 hover:bg-blue-600 hover:border-blue-600 rounded-2xl font-bold transition-all transform group-hover:-translate-y-1"
              >
                ارسال طلب التقديم
              </button>
            </div>
          ))}
        </div>

        <div className="mt-20 p-8 glass-panel rounded-3xl text-center border-blue-500/20">
          <h4 className="text-xl font-bold mb-2">ملاحظة هامة</h4>
          <p className="text-gray-500">يجب أن يكون لديك حساب ديسكورد مفعل وأن تكون قد قرأت قوانين القطاع قبل التقديم.</p>
        </div>
      </div>
    </div>
  );
};

export default ApplicationsPage;
