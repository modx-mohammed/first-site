
import React from 'react';

interface FooterProps {
  onNavigate: (target: 'home' | 'rules' | 'features' | 'staff' | 'store' | 'applications') => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const DISCORD_LINK = 'https://discord.gg/blaine';

  return (
    <footer className="py-12 px-6 border-t border-white/5 bg-[#0a0a0b]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4 cursor-pointer" onClick={() => onNavigate('home')}>
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold">B</div>
              <span className="text-xl font-bold tracking-tight">BLAINE <span className="text-blue-500 text-sm">FAVEM SERVER</span></span>
            </div>
            <p className="text-gray-500 text-sm max-w-xs leading-relaxed">جميع الحقوق محفوظة لسيرفر بلاين © 2024.</p>
          </div>
          
          <div className="flex gap-10 text-sm font-medium">
            <div className="flex flex-col gap-3 text-right">
              <span className="text-white font-bold mb-2">الروابط</span>
              <button onClick={() => onNavigate('rules')} className="text-gray-500 hover:text-white transition-colors text-right">القوانين</button>
              <button onClick={() => onNavigate('store')} className="text-gray-500 hover:text-white transition-colors text-right">المتجر</button>
              <button onClick={() => onNavigate('applications')} className="text-gray-500 hover:text-white transition-colors text-right">التقديمات</button>
              <button onClick={() => onNavigate('staff')} className="text-gray-500 hover:text-white transition-colors text-right">الإدارة</button>
            </div>
            <div className="flex flex-col gap-3 text-right">
              <span className="text-white font-bold mb-2">الدعم</span>
              <a href={DISCORD_LINK} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white transition-colors">الديسكورد</a>
              <a href={DISCORD_LINK} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white transition-colors">تذاكر الدعم</a>
              <a href={`mailto:support@blaine-rp.com`} className="text-gray-500 hover:text-white transition-colors text-right">تواصل معنا</a>
            </div>
          </div>
          
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-blue-400 transition-all">🐦</a>
            <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-red-600 transition-all">📺</a>
            <a href={DISCORD_LINK} className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-[#5865F2] transition-all">🎮</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
