
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updateUser } = useAuth();
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [status, setStatus] = useState(user?.status || '');

  if (!isOpen || !user) return null;

  const handleSave = () => {
    updateUser({ displayName, status });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative w-full max-w-lg glass-panel rounded-[2.5rem] border-white/10 overflow-hidden animate-in zoom-in duration-200">
        <div className="p-8 bg-blue-600/20 border-b border-white/5">
          <h2 className="text-2xl font-black">تعديل بيانات الملف</h2>
          <p className="text-gray-400 text-sm">تغيير المعلومات التي تظهر للآخرين على الموقع</p>
        </div>
        <div className="p-8 space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-400 mb-2">الاسم المستعار</label>
            <input 
              type="text" 
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-3 focus:border-blue-500 outline-none transition-all"
              placeholder="مثال: الباشا 77"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-400 mb-2">الحالة الشخصية (Bio)</label>
            <textarea 
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-3 focus:border-blue-500 outline-none transition-all h-24 resize-none"
              placeholder="اكتب شيئاً عن نفسك..."
            />
          </div>
          <div className="flex gap-4 mt-8">
            <button onClick={onClose} className="flex-1 py-4 bg-white/5 hover:bg-white/10 rounded-2xl font-bold transition-all">إلغاء</button>
            <button onClick={handleSave} className="flex-1 py-4 bg-blue-600 hover:bg-blue-700 rounded-2xl font-bold transition-all shadow-lg shadow-blue-500/20">حفظ التغييرات</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProfileModal;
