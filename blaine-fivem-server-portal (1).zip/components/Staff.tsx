
import React from 'react';
import { StaffMember } from '../types';

const staffMembers: StaffMember[] = [
  { id: '1', name: 'Al-Basha', role: 'مؤسس السيرفر', avatar: 'https://picsum.photos/id/1012/200/200' },
  { id: '2', name: 'Matrix', role: 'مدير التقنية', avatar: 'https://picsum.photos/id/1025/200/200' },
  { id: '3', name: 'Joker', role: 'رئيس الإدارة', avatar: 'https://picsum.photos/id/1074/200/200' },
  { id: '4', name: 'Nova', role: 'مشرف عام', avatar: 'https://picsum.photos/id/1005/200/200' },
];

const Staff: React.FC = () => {
  const openProfile = (name: string) => {
    // توجيه اللاعب للديسكورد كحل بديل لعرض الملفات الشخصية
    window.open('https://discord.gg/blaine', '_blank');
  };

  return (
    <section id="staff" className="py-24 px-6 bg-[#0c0c0e]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black mb-4 uppercase tracking-tight">طاقم الإدارة</h2>
          <div className="h-1.5 w-20 bg-blue-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {staffMembers.map((member) => (
            <div key={member.id} className="text-center p-8 glass-panel rounded-3xl group hover:bg-white/[0.05] transition-all">
              <div className="relative inline-block mb-6">
                <img 
                  src={member.avatar} 
                  alt={member.name} 
                  className="w-32 h-32 rounded-full object-cover border-4 border-white/5 group-hover:border-blue-500/50 transition-all"
                />
                <div className="absolute bottom-1 right-1 w-6 h-6 bg-green-500 border-4 border-[#0c0c0e] rounded-full"></div>
              </div>
              <h3 className="text-xl font-bold mb-1">{member.name}</h3>
              <p className="text-blue-500 text-sm font-bold mb-4 uppercase tracking-widest">{member.role}</p>
              <button 
                onClick={() => openProfile(member.name)}
                className="text-xs text-gray-500 hover:text-white border border-white/10 hover:border-white/30 px-4 py-1.5 rounded-full transition-all"
              >
                عرض الملف الشخصي
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Staff;
