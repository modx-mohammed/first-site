
import React, { useEffect } from 'react';

interface RulesPageProps {
  onBack: () => void;
}

const RulesPage: React.FC<RulesPageProps> = ({ onBack }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const categories = [
    {
      title: "القوانين العامة",
      icon: "📜",
      rules: [
        "يمنع الخروج عن الرول بلاي (Fail RP) تحت أي ظرف.",
        "يمنع استغلال الثغرات (Exploiting) أو استخدام البرامج المساعدة.",
        "يجب أن يكون اسم الشخصية واقعياً وثلاثياً.",
        "الاحترام المتبادل بين اللاعبين خارج نطاق الشخصية واجب."
      ]
    },
    {
      title: "قوانين القتال والجرائم",
      icon: "🔫",
      rules: [
        "يمنع القتل العشوائي (RDM) بدون سيناريو مسبق.",
        "يمنع استخدام المركبة كأداة للقتل (VDM).",
        "يجب إعطاء تنبيه كافٍ قبل البدء في إطلاق النار.",
        "قانون الحياة الجديدة (NLR): عند موتك تنسى جميع أحداث السيناريو الأخير."
      ]
    },
    {
      title: "قوانين السطو والسرقات",
      icon: "💰",
      rules: [
        "يجب توفر عدد محدد من الشرطة لبدء أي عملية سطو.",
        "يمنع الغدر بعد الاتفاق مع المفاوض.",
        "الرهائن يجب أن يكونوا لاعبين حقيقيين وليسوا أصدقاء لك.",
        "يمنع السرقة فوراً بعد خروج اللاعب من البنك أو المستشفى."
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <button 
              onClick={onBack}
              className="text-blue-500 hover:text-blue-400 font-bold flex items-center gap-2 mb-4 transition-colors"
            >
              <span>←</span> العودة للرئيسية
            </button>
            <h1 className="text-5xl font-black mb-2">دستور سيرفر <span className="text-blue-500">بلاين</span></h1>
            <p className="text-gray-500">يرجى قراءة القوانين بعناية لتجنب العقوبات الإدارية.</p>
          </div>
          <div className="bg-blue-600/10 border border-blue-600/20 p-4 rounded-2xl flex items-center gap-4">
            <div className="text-3xl">⚠️</div>
            <p className="text-sm text-blue-200 leading-tight">عدم معرفتك بالقوانين <br /><span className="font-bold">لا يعفيك من المسؤولية.</span></p>
          </div>
        </div>

        {/* Content */}
        <div className="grid gap-8">
          {categories.map((cat, idx) => (
            <div key={idx} className="glass-panel rounded-[2.5rem] overflow-hidden">
              <div className="bg-white/5 p-8 border-b border-white/5 flex items-center gap-4">
                <span className="text-4xl">{cat.icon}</span>
                <h2 className="text-2xl font-bold">{cat.title}</h2>
              </div>
              <div className="p-8">
                <ul className="grid gap-4">
                  {cat.rules.map((rule, ridx) => (
                    <li key={ridx} className="flex items-start gap-4 p-4 rounded-2xl hover:bg-white/[0.02] transition-colors border border-transparent hover:border-white/5">
                      <div className="w-6 h-6 rounded-full bg-blue-600/20 text-blue-500 flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">
                        {ridx + 1}
                      </div>
                      <p className="text-gray-300 font-medium leading-relaxed">{rule}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Footer CTA */}
        <div className="mt-16 text-center">
          <p className="text-gray-500 mb-6">هل لديك استفسار حول قانون معين؟</p>
          <button 
            onClick={() => window.open('https://discord.gg/blaine', '_blank')}
            className="bg-white text-black font-black px-10 py-4 rounded-2xl hover:bg-blue-600 hover:text-white transition-all transform hover:-translate-y-1"
          >
            تحدث مع الإدارة عبر الديسكورد
          </button>
        </div>
      </div>
    </div>
  );
};

export default RulesPage;
