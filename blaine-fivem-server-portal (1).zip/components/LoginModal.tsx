
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { CONFIG } from '../config';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { login } = useAuth();
  const [step, setStep] = useState<'initial' | 'redirecting'>('initial');

  if (!isOpen) return null;

  const handleDiscordLogin = () => {
    setStep('redirecting');
    
    // رابط OAuth2 الحقيقي
    const discordUrl = `https://discord.com/api/oauth2/authorize?client_id=${CONFIG.DISCORD.CLIENT_ID}&redirect_uri=${encodeURIComponent(CONFIG.DISCORD.REDIRECT_URI)}&response_type=code&scope=identify%20guilds`;
    
    // للبرمجة الفعلية: قم بإلغاء التعليق عن السطر التالي
    // window.location.href = discordUrl;

    // للمحاكاة الحالية (Simulation):
    setTimeout(() => {
        login({
          username: 'Basha_Player',
          displayName: 'الباشا الملكي',
          avatar: 'https://cdn.discordapp.com/embed/avatars/4.png',
          id: '8842',
          discordId: '123456789',
          status: 'مرحباً بك في ملفي الشخصي!',
          stats: {
            cash: 150000,
            bank: 2000000,
            points: 50,
            job: 'Police',
            rank: 'Chief',
            playtime: '150h',
            level: 10,
            warnings: 0,
            jailTime: 0,
            joinDate: '2024/01/01',
            vehicles: [],
            properties: [],
            licenses: { driver: true, pilot: false, weapon: true }
          }
        });
        onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative w-full max-w-md glass-panel rounded-[2.5rem] overflow-hidden animate-in zoom-in duration-300 border-white/5">
        {step === 'initial' ? (
          <>
            <div className="bg-blue-600 p-8 text-center relative">
              <div className="absolute top-4 right-4 text-white/50 hover:text-white cursor-pointer" onClick={onClose}>✕</div>
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">🔑</div>
              <h2 className="text-2xl font-black">بوابة اللاعبين</h2>
              <p className="text-blue-100 text-sm opacity-80">سجل دخولك عبر الديسكورد</p>
            </div>
            <div className="p-8 text-center">
              <button 
                onClick={handleDiscordLogin}
                className="w-full bg-[#5865F2] hover:bg-[#4752C4] py-4 rounded-2xl flex items-center justify-center gap-3 transition-all transform active:scale-95 group"
              >
                <span className="font-bold">تسجيل الدخول عبر ديسكورد</span>
              </button>
              <p className="mt-6 text-xs text-gray-500">سيتم ربط حسابك في الموقع مع هويتك في الديسكورد</p>
            </div>
          </>
        ) : (
          <div className="p-16 text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
            <h3 className="font-bold">جاري توجيهك إلى Discord...</h3>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginModal;
