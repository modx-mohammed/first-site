
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';

interface FloatingEffect {
  id: number;
  x: number;
  y: number;
  text: string;
}

interface ReceiptData {
  itemName: string;
  itemIcon: string;
  date: string;
  day: string;
  time: string;
  transactionId: string;
}

const GameHub: React.FC = () => {
  const { user, updateStats } = useAuth();
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [items, setItems] = useState<{ id: number; top: number; left: number }[]>([]);
  const [effects, setEffects] = useState<FloatingEffect[]>([]);
  const [isProcessing, setIsProcessing] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);
  const [showInstructions, setShowInstructions] = useState(false);
  const gameInterval = useRef<any>(null);

  const rewards = [
    { id: 'ticket', name: 'تذكرة تواصل إدارية', cost: 50, icon: '🎫', desc: 'افتح تواصل مباشر مع الإدارة' },
    { id: 'rank', name: 'رتبة "مميز" ديسكورد', cost: 200, icon: '🎖️', desc: 'لون خاص ومميزات في الديسكورد' },
    { id: 'car', name: 'سيارة Dodge Viper', cost: 1000, icon: '🏎️', desc: 'سيارة رياضية حصرية لمرة واحدة' },
    { id: 'vip', name: 'اشتراك VIP أسبوع', cost: 500, icon: '💎', desc: 'دخول سريع ومميزات إضافية' },
  ];

  const startGame = () => {
    setIsPlaying(true);
    setScore(0);
    setTimeLeft(20);
    setItems([]);
    setEffects([]);
    setReceipt(null);
  };

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      gameInterval.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
        spawnItem();
      }, 800);
    } else if (timeLeft === 0) {
      clearInterval(gameInterval.current);
      setIsPlaying(false);
      if (score > 0) {
        updateStats({ points: (user?.stats.points || 0) + score });
      }
    }
    return () => clearInterval(gameInterval.current);
  }, [isPlaying, timeLeft]);

  const spawnItem = () => {
    const newItem = {
      id: Math.random(),
      top: Math.random() * 70 + 15,
      left: Math.random() * 70 + 15,
    };
    setItems(prev => [...prev, newItem]);
    setTimeout(() => {
      setItems(prev => prev.filter(i => i.id !== newItem.id));
    }, 1500);
  };

  const handleItemClick = (e: React.MouseEvent, item: any) => {
    e.stopPropagation();
    setScore(prev => prev + 5);
    setItems(prev => prev.filter(i => i.id !== item.id));
    
    const newEffect = {
      id: Date.now(),
      x: item.left,
      y: item.top,
      text: '+5'
    };
    setEffects(prev => [...prev, newEffect]);
    setTimeout(() => {
      setEffects(prev => prev.filter(eff => eff.id !== newEffect.id));
    }, 1000);
  };

  const redeemReward = (reward: typeof rewards[0]) => {
    if ((user?.stats.points || 0) >= reward.cost) {
      setIsProcessing(reward.id);
      
      setTimeout(() => {
        const now = new Date();
        const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        
        const newReceipt: ReceiptData = {
          itemName: reward.name,
          itemIcon: reward.icon,
          date: now.toLocaleDateString('ar-SA'),
          day: days[now.getDay()],
          time: now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
          transactionId: 'TXN-' + Math.random().toString(36).substr(2, 9).toUpperCase()
        };

        updateStats({ points: user!.stats.points - reward.cost });
        setIsProcessing(null);
        setReceipt(newReceipt);
      }, 1500);
    } else {
      alert('❌ عذراً! رصيد نقاطك غير كافي لهذه المكافأة.');
    }
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-5">
      {/* Instructions Modal */}
      {showInstructions && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl animate-in fade-in duration-300" onClick={() => setShowInstructions(false)}></div>
          <div className="relative w-full max-w-2xl glass-panel rounded-[3rem] overflow-hidden border-white/10 animate-in zoom-in duration-300">
            <div className="p-10">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black flex items-center gap-4">
                  <span className="text-4xl">📘</span> تعليمات نظام المكافآت
                </h2>
                <button onClick={() => setShowInstructions(false)} className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-2xl hover:bg-red-500 transition-colors">×</button>
              </div>

              <div className="grid gap-8">
                <div className="flex gap-6">
                  <div className="w-16 h-16 shrink-0 bg-yellow-500/20 rounded-[1.5rem] flex items-center justify-center text-3xl font-black text-yellow-500">1</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">كيفية جمع النقاط (XP)</h4>
                    <p className="text-gray-400 leading-relaxed">ادخل إلى لعبة "Data Miner" واضغط على العملات الذهبية التي تظهر عشوائياً. كل عملة تمنحك 5 نقاط. تنتهي الجولة بعد 20 ثانية ويتم إضافة النقاط لرصيدك تلقائياً.</p>
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="w-16 h-16 shrink-0 bg-blue-600/20 rounded-[1.5rem] flex items-center justify-center text-3xl font-black text-blue-500">2</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">استبدال النقاط بالمكافآت</h4>
                    <p className="text-gray-400 leading-relaxed">عند تجميع رصيد كافٍ، يمكنك الذهاب إلى سوق المكافآت واختيار الغرض الذي تريده. سيتم خصم النقاط من حسابك فور تأكيد العملية.</p>
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="w-16 h-16 shrink-0 bg-green-500/20 rounded-[1.5rem] flex items-center justify-center text-3xl font-black text-green-500">3</div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">التوثيق واستلام الجائزة</h4>
                    <p className="text-gray-400 leading-relaxed">هذه أهم خطوة! بعد الاستبدال، سيظهر لك <span className="text-white font-bold">كرت وصل إلكتروني</span>. يجب عليك أخذ لقطة شاشة (Screenshot) له، ثم التوجه لديسكورد السيرفر وفتح تذكرة (Ticket) وإرسال الصورة للإدارة لتسليمك الجائزة داخل السيرفر.</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setShowInstructions(false)}
                className="w-full mt-12 py-5 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl transition-all shadow-xl shadow-blue-500/20"
              >
                حسناً، بدأت أفهم الآن!
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Modal */}
      {receipt && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl animate-in fade-in duration-500"></div>
          <div className="relative w-full max-w-md glass-panel rounded-[3rem] overflow-hidden border-blue-500/30 animate-in zoom-in duration-300 shadow-[0_0_50px_rgba(59,130,246,0.2)]">
            <div className="bg-gradient-to-b from-blue-600 to-blue-800 p-8 text-center">
              <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-xl transform rotate-3">
                {receipt.itemIcon}
              </div>
              <h2 className="text-2xl font-black text-white">تم الاستبدال بنجاح!</h2>
              <p className="text-blue-100 text-sm opacity-80 uppercase tracking-widest font-bold mt-1">Voucher Created</p>
            </div>

            <div className="p-8 space-y-6">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <span className="text-gray-400 font-bold">المكافأة</span>
                <span className="text-white font-black text-lg">{receipt.itemName}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-4 rounded-2xl">
                  <p className="text-[10px] text-gray-500 font-black mb-1 uppercase">اليوم</p>
                  <p className="font-bold">{receipt.day}</p>
                </div>
                <div className="bg-white/5 p-4 rounded-2xl">
                  <p className="text-[10px] text-gray-500 font-black mb-1 uppercase">الوقت</p>
                  <p className="font-bold">{receipt.time}</p>
                </div>
              </div>

              <div className="bg-white/5 p-4 rounded-2xl flex justify-between items-center">
                <div>
                  <p className="text-[10px] text-gray-500 font-black mb-1 uppercase">التاريخ</p>
                  <p className="font-bold">{receipt.date}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-gray-500 font-black mb-1 uppercase">رقم العملية</p>
                  <p className="font-mono font-bold text-blue-400 text-xs">{receipt.transactionId}</p>
                </div>
              </div>

              <div className="bg-yellow-500/10 border border-yellow-500/20 p-6 rounded-3xl text-center">
                <p className="text-yellow-500 font-black text-sm mb-2">⚠️ تعليمات هامة جداً</p>
                <p className="text-gray-300 text-xs leading-relaxed">
                  يجب عليك <span className="text-white font-bold underline">تصوير هذا الكرت (Screenshot)</span> الآن، ثم التوجه للديسكورد وفتح تذكرة إدارية وتقديم الصورة لاستلام مكافأتك.
                </p>
              </div>

              <button 
                onClick={() => setReceipt(null)}
                className="w-full py-4 bg-white text-black font-black rounded-2xl hover:bg-blue-600 hover:text-white transition-all shadow-xl active:scale-95"
              >
                فهمت، إغلاق الوصل
              </button>
            </div>
            
            <div className="absolute top-1/2 -left-4 w-8 h-8 bg-black rounded-full transform -translate-y-1/2"></div>
            <div className="absolute top-1/2 -right-4 w-8 h-8 bg-black rounded-full transform -translate-y-1/2"></div>
          </div>
        </div>
      )}

      {/* Points Card */}
      <div className="glass-panel p-10 rounded-[3rem] bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/20 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 blur-3xl rounded-full"></div>
        <div className="flex items-center gap-6 relative z-10">
          <div className="w-20 h-20 bg-yellow-500 rounded-[2rem] flex items-center justify-center text-4xl shadow-2xl shadow-yellow-500/30 transform -rotate-6">🪙</div>
          <div>
            <h3 className="text-4xl font-black">رصيدك: {user?.stats.points || 0}</h3>
            <p className="text-gray-400 font-bold mt-1">استخدم نقاطك بحكمة في سوق المكافآت</p>
          </div>
        </div>
        <button 
          onClick={startGame}
          disabled={isPlaying}
          className="bg-white text-black hover:bg-yellow-500 font-black px-12 py-5 rounded-[2rem] transition-all transform active:scale-95 disabled:opacity-50 disabled:scale-100 shadow-xl shadow-white/5 relative z-10"
        >
          {isPlaying ? (
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
              جاري اللعب ({timeLeft}ث)
            </div>
          ) : '🎮 العب واجمع النقاط'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Mini Game Area */}
        <div className="glass-panel rounded-[3rem] h-[500px] relative overflow-hidden bg-[#050505] border-white/5 flex flex-col shadow-inner">
          <div className="p-6 bg-white/5 border-b border-white/5 flex justify-between items-center z-20">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
              <span className="font-black text-sm uppercase tracking-widest">Data Miner Pro</span>
            </div>
            <div className="bg-yellow-500/10 text-yellow-500 px-6 py-2 rounded-2xl font-black text-lg border border-yellow-500/20">
              {score} XP
            </div>
          </div>
          
          <div className="flex-1 relative cursor-crosshair" onClick={() => !isPlaying && startGame()}>
            {!isPlaying ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-12 group transition-all">
                <div className="w-32 h-32 bg-yellow-500/5 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <span className="text-7xl animate-bounce">🪙</span>
                </div>
                <h4 className="text-2xl font-black mb-2">هل أنت مستعد؟</h4>
                <p className="text-gray-500 text-lg max-w-xs">انقر على العملات المتطايرة بأسرع ما يمكن لجمع أكبر قدر من النقاط!</p>
                <p className="mt-8 text-xs text-yellow-500/50 font-bold uppercase tracking-widest">انقر للبدء</p>
              </div>
            ) : (
              <>
                {items.map(item => (
                  <button
                    key={item.id}
                    onMouseDown={(e) => handleItemClick(e, item)}
                    style={{ top: `${item.top}%`, left: `${item.left}%` }}
                    className="absolute w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center text-3xl shadow-2xl shadow-yellow-500/50 animate-in zoom-in duration-200 z-[60] hover:scale-110 active:scale-90 transition-transform border-2 border-white/20"
                  >
                    🪙
                  </button>
                ))}
                {effects.map(eff => (
                  <div 
                    key={eff.id}
                    style={{ top: `${eff.y}%`, left: `${eff.x}%` }}
                    className="absolute text-yellow-400 font-black text-2xl z-[70] pointer-events-none animate-out slide-out-to-top-10 fade-out duration-1000"
                  >
                    {eff.text}
                  </div>
                ))}
              </>
            )}
          </div>
        </div>

        {/* Redeem Shop */}
        <div className="space-y-8">
          <h3 className="text-3xl font-black flex items-center gap-4">
            <span className="w-1.5 h-10 bg-blue-600 rounded-full"></span>
            سوق المكافآت الحصرية
          </h3>
          <div className="grid gap-5">
            {rewards.map(reward => (
              <div key={reward.id} className="glass-panel p-6 rounded-[2rem] border-white/5 flex items-center justify-between group hover:bg-white/[0.04] transition-all border-l-4 border-l-transparent hover:border-l-blue-600">
                <div className="flex items-center gap-5">
                  <div className="text-4xl bg-white/5 w-16 h-16 rounded-[1.5rem] flex items-center justify-center group-hover:bg-blue-600/10 group-hover:text-blue-500 transition-all transform group-hover:rotate-6 shadow-lg border border-white/5">{reward.icon}</div>
                  <div>
                    <h4 className="font-black text-xl mb-0.5">{reward.name}</h4>
                    <p className="text-sm text-gray-500 leading-relaxed">{reward.desc}</p>
                  </div>
                </div>
                <button 
                  onClick={() => redeemReward(reward)}
                  disabled={isProcessing !== null}
                  className={`min-w-[120px] py-4 rounded-2xl font-black transition-all flex flex-col items-center justify-center gap-1 shadow-xl active:scale-95 ${
                    (user?.stats.points || 0) >= reward.cost 
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20' 
                    : 'bg-white/5 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {isProcessing === reward.id ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span className="text-sm">استبدال</span>
                      <span className="text-[10px] opacity-70 bg-black/20 px-2 py-0.5 rounded-full">{reward.cost} نقطة</span>
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>

          <div className="p-8 bg-blue-600/10 border border-blue-600/20 rounded-[2.5rem] text-center">
             <p className="text-gray-400 text-sm mb-4">هل لديك استفسار عن نظام النقاط؟</p>
             <button 
                onClick={() => setShowInstructions(true)}
                className="text-blue-400 font-black hover:text-white transition-colors"
             >
                قراءة التعليمات الكاملة ←
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameHub;
