
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import LoginModal from './LoginModal';

interface NavbarProps {
  onNavigate: (target: 'home' | 'rules' | 'features' | 'staff' | 'store' | 'applications' | 'profile') => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const [scrolled, setScrolled] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  
  const SERVER_IP = '127.0.0.1';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-[105] transition-all duration-300 ${scrolled ? 'bg-[#0a0a0b]/80 backdrop-blur-md border-b border-white/10 py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl shadow-lg shadow-blue-500/20">B</div>
            <span className="text-xl font-bold tracking-tight">BLAINE <span className="text-blue-500">SERVER</span></span>
          </div>
          
          <div className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button onClick={() => onNavigate('home')} className="hover:text-blue-400 transition-colors text-right">الرئيسية</button>
            <button onClick={() => onNavigate('rules')} className="hover:text-blue-400 transition-colors">القوانين</button>
            <button onClick={() => onNavigate('applications')} className="hover:text-blue-400 transition-colors bg-white/5 px-4 py-1.5 rounded-lg border border-white/5">التقديمات</button>
            <button onClick={() => onNavigate('staff')} className="hover:text-blue-400 transition-colors">الإدارة</button>
            <button onClick={() => onNavigate('features')} className="hover:text-blue-400 transition-colors">المميزات</button>
            <button onClick={() => onNavigate('store')} className="hover:text-blue-400 transition-colors text-yellow-500 font-bold">المتجر</button>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated && user ? (
              <div className="relative">
                <button 
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-3 bg-white/5 hover:bg-white/10 p-1.5 pr-4 rounded-full border border-white/10 transition-all"
                >
                  <span className="text-sm font-bold">{user.username}</span>
                  <img src={user.avatar} className="w-8 h-8 rounded-full border border-white/20" alt="Avatar" />
                </button>
                
                {isUserMenuOpen && (
                  <div className="absolute top-full left-0 mt-2 w-48 glass-panel rounded-2xl overflow-hidden py-2 animate-in fade-in slide-in-from-top-2">
                    <button 
                      onClick={() => { onNavigate('profile'); setIsUserMenuOpen(false); }} 
                      className="w-full px-4 py-2 text-right text-sm hover:bg-white/5 transition-colors"
                    >
                      الملف الشخصي
                    </button>
                    <button 
                      onClick={() => { onNavigate('profile'); setIsUserMenuOpen(false); }} 
                      className="w-full px-4 py-2 text-right text-sm hover:bg-white/5 transition-colors"
                    >
                      إحصائياتي
                    </button>
                    <div className="h-px bg-white/5 my-2"></div>
                    <button 
                      onClick={() => { logout(); setIsUserMenuOpen(false); }}
                      className="w-full px-4 py-2 text-right text-sm text-red-500 hover:bg-red-500/10 transition-colors"
                    >
                      تسجيل الخروج
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button 
                onClick={() => setIsLoginOpen(true)} 
                className="hidden sm:block text-sm font-medium hover:text-blue-400 transition-colors"
              >
                تسجيل الدخول
              </button>
            )}
            
            <button onClick={() => window.location.href = `fivem://connect/${SERVER_IP}`} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full text-sm font-bold transition-all shadow-lg shadow-blue-500/25">
              انضم الآن
            </button>
          </div>
        </div>
      </nav>

      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
    </>
  );
};

export default Navbar;
