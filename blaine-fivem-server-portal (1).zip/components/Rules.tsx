
import React from 'react';
import { Rule } from '../types';

interface RulesProps {
  onNavigate: (target: 'home' | 'rules') => void;
}

const rulesList: Rule[] = [
  { id: 1, title: 'الواقعية (Roleplay)', content: 'يجب عليك تمثيل شخصيتك بكل واقعية والابتعاد عن الأفعال التي لا يمكن فعلها في الحياة الواقعية.' },
  { id: 2, title: 'القتل العشوائي (RDM)', content: 'يمنع منعاً باتاً قتل أي لاعب بدون وجود سبب رول بلاي قوي وواضح مسبقاً.' },
  { id: 3, title: 'الدهس العشوائي (VDM)', content: 'استخدام المركبة كسلاح لدهس اللاعبين دون سبب مبرر يعرضك للحظر النهائي.' },
  { id: 4, title: 'الخروج من السيناريو (Fail RP)', content: 'يمنع التحدث عن أشياء خارج اللعبة أو الانسحاب من سيناريو قائم بشكل مفاجئ.' },
];

const Rules: React.FC<RulesProps> = ({ onNavigate }) => {
  return (
    <section id="rules" className="py-24 px-6 bg-[#0a0a0b]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black mb-4 uppercase tracking-tight">قوانين السيرفر</h2>
          <div className="h-1.5 w-20 bg-blue-600 mx-auto rounded-full"></div>
          <p className="text-gray-500 mt-6 max-w-xl mx-auto">نلتزم في بلاين بأعلى معايير الرول بلاي لضمان تجربة ممتعة وعادلة لجميع اللاعبين.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {rulesList.map((rule) => (
            <div key={rule.id} className="glass-panel p-8 rounded-3xl hover:border-blue-500/50 transition-all group">
              <div className="flex items-start gap-6">
                <div className="w-14 h-14 shrink-0 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500 text-2xl font-black group-hover:bg-blue-500 group-hover:text-white transition-all">
                  {rule.id}
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-3">{rule.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{rule.content}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button 
            onClick={() => onNavigate('rules')}
            className="group inline-flex items-center gap-3 text-blue-500 font-bold hover:text-white transition-all"
          >
            <span>عرض كافة القوانين والتفاصيل</span>
            <span className="group-hover:translate-x-[-5px] transition-transform">←</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default Rules;
