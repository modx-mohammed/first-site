
import React, { useEffect } from 'react';

interface StorePageProps {
  onBack: () => void;
}

const StorePage: React.FC<StorePageProps> = ({ onBack }) => {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  const packages = [
    { name: 'VIP الذهبية', price: '49.99$', features: ['أولوية دخول السيرفر', 'سيارة حصرية شهرياً', 'رتبة خاصة بالديسكورد'], color: 'from-yellow-500/20 to-yellow-600/40' },
    { name: 'حزمة البداية', price: '19.99$', features: ['500k كاش باللعبة', 'رخصة سلاح فورية', 'منزل متوسط المستوى'], color: 'from-blue-500/20 to-blue-600/40' },
    { name: 'VIP الماسية', price: '99.99$', features: ['جميع مميزات الذهبية', 'إمكانية فتح عصابة', 'تغيير اسم الشخصية مجاناً'], color: 'from-purple-500/20 to-purple-600/40' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto">
        <button onClick={onBack} className="text-blue-500 hover:text-blue-400 font-bold flex items-center gap-2 mb-8">
          <span>←</span> العودة للرئيسية
        </button>
        <div className="text-center mb-16">
          <h1 className="text-5xl font-black mb-4">متجر <span className="text-blue-500">بلاين</span></h1>
          <p className="text-gray-500">ادعم السيرفر واحصل على مميزات حصرية تجعل تجربتك أمتع.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, i) => (
            <div key={i} className={`glass-panel p-10 rounded-[3rem] border-t-4 border-blue-500 flex flex-col`}>
              <h3 className="text-2xl font-black mb-2">{pkg.name}</h3>
              <p className="text-4xl font-black text-blue-500 mb-8">{pkg.price}</p>
              <ul className="space-y-4 mb-12 flex-1">
                {pkg.features.map((f, fi) => (
                  <li key={fi} className="flex items-center gap-3 text-gray-400">
                    <span className="text-blue-500">✓</span> {f}
                  </li>
                ))}
              </ul>
              <button onClick={() => window.open('https://tebex.io', '_blank')} className="w-full py-4 bg-blue-600 hover:bg-blue-700 rounded-2xl font-black transition-all shadow-lg shadow-blue-500/20">
                شراء الحزمة الآن
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StorePage;
