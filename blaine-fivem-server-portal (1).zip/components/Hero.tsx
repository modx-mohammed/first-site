
import React from 'react';

const Hero: React.FC = () => {
  const SERVER_IP = '127.0.0.1'; // استبدل بـ IP السيرفر الخاص بك
  const DISCORD_LINK = 'https://discord.gg/blaine'; // استبدل برابط ديسكورد السيرفر

  const handleJoin = () => {
    window.location.href = `fivem://connect/${SERVER_IP}`;
  };

  const handleDiscord = () => {
    window.open(DISCORD_LINK, '_blank');
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1544652478-6653e09f18a2?q=80&w=2070&auto=format&fit=crop" 
          alt="GTA Background" 
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0b] via-[#0a0a0b]/60 to-transparent"></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl">
        <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-bold tracking-widest uppercase animate-pulse">
          أهلاً بك في عالم الواقعية
        </div>
        <h1 className="text-5xl md:text-8xl font-black mb-6 leading-tight">
          سيرفر <span className="gradient-text">بلاين</span> <br />
          <span className="text-white/90">للرول بلاي الواقعي</span>
        </h1>
        <p className="text-gray-400 text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
          انضم إلى أقوى مجتمع FiveM عربي. حياة واقعية، وظائف متقدمة، واقتصاد متوازن ينتظرك الآن.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={handleJoin}
            className="w-full sm:w-auto px-10 py-4 bg-white text-black font-black rounded-xl hover:bg-blue-600 hover:text-white transition-all transform hover:-translate-y-1 shadow-2xl"
          >
            دخول السيرفر
          </button>
          <button 
            onClick={handleDiscord}
            className="w-full sm:w-auto px-10 py-4 bg-white/5 border border-white/10 text-white font-black rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2"
          >
            <span>🎮</span> ديسكورد السيرفر
          </button>
        </div>

        <div className="mt-16 flex justify-center gap-12">
          <div className="text-center">
            <p className="text-3xl font-black text-white">128+</p>
            <p className="text-sm text-gray-500 uppercase tracking-widest font-bold">لاعب متصل</p>
          </div>
          <div className="w-[1px] h-12 bg-white/10"></div>
          <div className="text-center">
            <p className="text-3xl font-black text-white">5000+</p>
            <p className="text-sm text-gray-500 uppercase tracking-widest font-bold">عضو ديسكورد</p>
          </div>
          <div className="w-[1px] h-12 bg-white/10"></div>
          <div className="text-center">
            <p className="text-3xl font-black text-white">24/7</p>
            <p className="text-sm text-gray-500 uppercase tracking-widest font-bold">حماية متواصلة</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
