
import React, { useEffect } from 'react';

interface StaffPageProps {
  onBack: () => void;
}

const StaffPage: React.FC<StaffPageProps> = ({ onBack }) => {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  const staff = [
    { name: 'Al-Basha', role: 'مؤسس السيرفر', desc: 'المسؤول الأول عن رؤية وتطوير السيرفر.', avatar: 'https://picsum.photos/id/1012/200/200' },
    { name: 'Matrix', role: 'مدير التقنية', desc: 'خبير السكربتات والبرمجة الخاصة بالسيرفر.', avatar: 'https://picsum.photos/id/1025/200/200' },
    { name: 'Joker', role: 'رئيس الإدارة', desc: 'المسؤول عن تنظيم شؤون اللاعبين والشكاوى.', avatar: 'https://picsum.photos/id/1074/200/200' },
    { name: 'Nova', role: 'مشرف عام', desc: 'مراقب جودة الرول بلاي والفعاليات.', avatar: 'https://picsum.photos/id/1005/200/200' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0b] pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto text-center">
        <div className="text-right">
          <button onClick={onBack} className="text-blue-500 hover:text-blue-400 font-bold flex items-center gap-2 mb-8">
            <span>←</span> العودة للرئيسية
          </button>
        </div>
        <h1 className="text-5xl font-black mb-4">طاقم إدارة <span className="text-blue-500">بلاين</span></h1>
        <p className="text-gray-500 mb-16 max-w-2xl mx-auto">نخبة من المحترفين يعملون على مدار الساعة لضمان أفضل تجربة لعب.</p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {staff.map((s, i) => (
            <div key={i} className="glass-panel p-8 rounded-[2.5rem] group hover:border-blue-500/50 transition-all">
              <img src={s.avatar} className="w-24 h-24 rounded-full mx-auto mb-6 border-4 border-white/5 group-hover:border-blue-500/30 transition-all" />
              <h3 className="text-xl font-bold mb-1">{s.name}</h3>
              <p className="text-blue-500 text-xs font-bold uppercase mb-4 tracking-widest">{s.role}</p>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">{s.desc}</p>
              <button onClick={() => window.open('https://discord.gg/blaine', '_blank')} className="w-full py-3 bg-white/5 hover:bg-blue-600 rounded-xl transition-all font-bold text-sm">
                تواصل ديسكورد
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StaffPage;
