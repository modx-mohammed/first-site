
/**
 * ملف الإعدادات المركزي لسيرفر بلاين
 * يمكنك تعديل هذه القيم لربط الموقع بالسيرفر والديسكورد بسهولة
 */

export const CONFIG = {
  // معلومات السيرفر
  SERVER: {
    NAME: "Blaine Server",
    IP: "127.0.0.1", // IP السيرفر الخاص بك
    PORT: "30120",   // بورت السيرفر الافتراضي لـ FiveM
    CfxId: "your_cfx_id", // معرف CFX إذا كنت تستخدمه
    VERSION: "V4.5 Stable",
  },

  // إعدادات الديسكورد (OAuth2)
  DISCORD: {
    CLIENT_ID: "123456789012345678", // احصل عليه من Discord Developer Portal
    REDIRECT_URI: "http://localhost:3000/callback", // رابط العودة بعد تسجيل الدخول
    INVITE_LINK: "https://discord.gg/blaine",
  },

  // إعدادات الـ API (إذا كان لديك Backend)
  API_BASE_URL: "https://api.blaine-rp.com/v1", // رابط الـ API الخاص بك
  
  // روابط خارجية
  STORE_URL: "https://blaine.tebex.io",
};
