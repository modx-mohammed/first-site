
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
أنت المساعد الذكي لسيرفر "بلاين" (Blaine) في FiveM. 
مهمتك هي مساعدة اللاعبين الجدد والحاليين. 
معلومات السيرفر:
- الاسم: سيرفر بلاين (Blaine Server).
- النوع: رول بلاي واقعي (Serious RP).
- القوانين الأساسية: يمنع الـ RDM (القتل العشوائي)، يمنع الـ VDM (الدهس العشوائي)، يجب الالتزام بالواقعية التامة.
- الديسكورد: discord.gg/blaine.
- مميزاتنا: سيارات واقعية، وظائف متنوعة، نظام بنوك متطور، طاقم إدارة متواجد 24/7.
- كن ودوداً، مختصراً، واستخدم الرموز التعبيرية. أجِب دائماً باللغة العربية.
`;

export const getAIResponse = async (userMessage: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text || "عذراً، واجهت مشكلة في معالجة طلبك.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "عذراً، حدث خطأ ما أثناء الاتصال بالمساعد الذكي.";
  }
};
